﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Attribute = DDD.Domain.Models.Attribute;
using System.Threading.Tasks;

namespace DDD.Application.Repos.Interfaces;

interface IAttributeRepository : IRepository<Attribute>
{
    Task Update(Attribute category);
    Task<Attribute>? FindByIdAsync(int id);
}
