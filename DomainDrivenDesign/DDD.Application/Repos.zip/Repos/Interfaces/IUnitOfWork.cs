﻿using DDD.Application.Repos.Classes;
using DDD.Domain.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DDD.Application.Repos.Interfaces;

interface IUnitOfWork
{
    public AttributeRepository AttributeRepository{ get;  }
    public Task SaveChangesAsync();
}
