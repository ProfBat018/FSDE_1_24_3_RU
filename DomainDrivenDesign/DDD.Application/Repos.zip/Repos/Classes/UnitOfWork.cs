﻿using DDD.Application.Repos.Interfaces;
using DDD.Infrastructure.Contexts;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DDD.Application.Repos.Classes;

class UnitOfWork : IUnitOfWork
{
    public AttributeRepository AttributeRepository { get; private set; }
    private readonly EcommerceDbContext _context;
    public UnitOfWork(EcommerceDbContext context)
    {
        _context = context;
        AttributeRepository = new AttributeRepository(context);
    }

    public async Task SaveChangesAsync()
    {
        await _context.SaveChangesAsync();
    }
}
