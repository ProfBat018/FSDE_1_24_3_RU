﻿using DDD.Application.Repos.Interfaces;
using DDD.Infrastructure.Contexts;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Text;
using System.Threading.Tasks;

namespace DDD.Application.Repos.Classes;

public class Repository<T> : IRepository<T> where T : class
{
    private readonly EcommerceDbContext _context;
    private protected DbSet<T> dbSet;
    
    public Repository(EcommerceDbContext context)
    {
        _context = context;
        dbSet = _context.Set<T>();
    }

    public async Task AddAsync(T entity)
    {
        await dbSet.AddAsync(entity); 
    }
    public async Task<IEnumerable<TResult>> GetAll<TResult>(
    Expression<Func<T, bool>>? filter = null,
    Expression<Func<T, TResult>>? selectFilter = null,
    string? includeProperties = null)
    {
        IQueryable<T> query = dbSet;

        if (filter != null)
        {
            query = query.Where(filter);
        }

        if (!string.IsNullOrWhiteSpace(includeProperties))
        {
            var tables = includeProperties.Split(',', StringSplitOptions.RemoveEmptyEntries);
            foreach (var table in tables)
            {
                query = query.Include(table.Trim());
            }
        }

        if (selectFilter != null)
        {
            return await query.Select(selectFilter).ToListAsync();
        }
        else
        {
            return await query.Cast<TResult>().ToListAsync();
        }
    }


    public Task<TResult?> GetFirstOrDefault<TResult>(Expression<Func<T, bool>> filter, Expression<Func<T, TResult>>? selectFilter = null, string? includeProperties = null, bool tracked = true)
    {
        throw new NotImplementedException();
    }

    public void Remove(T entity)
    {
        throw new NotImplementedException();
    }

    public void RemoveRange(IEnumerable<T> entity)
    {
        throw new NotImplementedException();
    }
}